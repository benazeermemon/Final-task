from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = "supersecretkey"

@app.route("/")
def welcome():
    return render_template("welcome.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        session["username"] = username
        return redirect(url_for("home"))
    return render_template("login.html")

@app.route("/home")
def home():
    if "username" not in session:
        return redirect(url_for("login"))
    username = session["username"]
    return render_template("home.html", username=username)
@app.route("/features")
def features():
    if "username" not in session:
        return redirect(url_for("login"))
    return render_template("features.html")

@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect(url_for("welcome"))

if __name__ == "__main__":
    app.run(debug=True)